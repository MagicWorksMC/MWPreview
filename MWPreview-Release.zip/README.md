# MWPreview
The preview resource pack for MagicWorksMC
